package com.lti.hackathon.exam.portal.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.hackathon.exam.portal.entity.QuestionBank;
import com.lti.hackathon.exam.portal.entity.RegisterStudent;

@Repository
public class QuestionOperationsDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void addQuestion(QuestionBank questionBank) {
		entityManager.persist(questionBank);
	}

	public List<QuestionBank> fetchQuestionsByDomainAndLevel(String domain, int stage) {
		
		TypedQuery<QuestionBank> q=entityManager.createQuery("select ques from QuestionBank as ques where ques.stage=:stage and ques.domain=:domain ", QuestionBank.class);
		q.setParameter("domain", domain);
		q.setParameter("stage",stage);
		return q.getResultList();
	}

}
