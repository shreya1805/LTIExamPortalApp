package com.lti.hackathon.exam.portal.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.hackathon.exam.portal.entity.RegisterStudent;

@Repository
public class AdminAndStudentValidationDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public List<RegisterStudent> fetchAll() {
		TypedQuery<RegisterStudent> q=entityManager.createQuery("select obj from RegisterStudent as obj", RegisterStudent.class);
		return q.getResultList();
	}
}
