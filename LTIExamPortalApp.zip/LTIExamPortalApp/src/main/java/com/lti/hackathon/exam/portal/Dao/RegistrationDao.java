package com.lti.hackathon.exam.portal.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.lti.hackathon.exam.portal.entity.RegisterStudent;

@Repository
public class RegistrationDao {

	@PersistenceContext
	private EntityManager entityManager;

	public void registerStudentInDatabase(RegisterStudent registerStudent) {
		entityManager.persist(registerStudent);
	}

	public RegisterStudent fetchStudentDetails(int id) {
		return entityManager.find(RegisterStudent.class, id);
	}

}
