package com.lti.hackathon.exam.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.hackathon.exam.portal.entity.RegisterStudent;
import com.lti.hackathon.exam.portal.service.AdminAndStudentLoginValidationService;

@RestController
@CrossOrigin
public class AdminAndStudentLoginController {

		@Autowired
		private AdminAndStudentLoginValidationService adminAndStudentLoginValidationService;
		
		
		@RequestMapping(path="/verify",method=RequestMethod.POST)
		public boolean login(@RequestBody RegisterStudent registerStudent) {
			boolean flag=adminAndStudentLoginValidationService.verify(registerStudent);
			//String flag1=Boolean.toString(flag);
			//System.out.println("Verified");
			//return flag1;
			return flag;
		}

}
