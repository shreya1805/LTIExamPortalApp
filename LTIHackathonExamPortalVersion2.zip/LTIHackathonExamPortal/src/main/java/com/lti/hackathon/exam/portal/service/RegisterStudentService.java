package com.lti.hackathon.exam.portal.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hackathon.exam.portal.Dao.RegistrationDao;
import com.lti.hackathon.exam.portal.entity.RegisterStudent;

@Service
public class RegisterStudentService {

	@Autowired
	private RegistrationDao registrationDao;

	@Transactional
	public boolean registerStudentInDatabase(RegisterStudent registerStudent) {
		registrationDao.registerStudentInDatabase(registerStudent);
		return true;
	}

	public RegisterStudent fetchStudentDetails(int id) {
		return registrationDao.fetchStudentDetails(id);
	}

}
