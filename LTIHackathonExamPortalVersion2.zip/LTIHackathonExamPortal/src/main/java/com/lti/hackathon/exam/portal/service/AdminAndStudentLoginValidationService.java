package com.lti.hackathon.exam.portal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hackathon.exam.portal.Dao.AdminAndStudentValidationDao;
import com.lti.hackathon.exam.portal.entity.RegisterStudent;

@Service
public class AdminAndStudentLoginValidationService {

	@Autowired
	private AdminAndStudentValidationDao adminAndStudentValidationDao;

	@Transactional
	public boolean verify(RegisterStudent registerStudent) {
		String fetchedEmail = registerStudent.getEmailAddress();
		String fetchedPassword = registerStudent.getPassword();
		boolean flag = false;
		List<RegisterStudent> studentEmailList = adminAndStudentValidationDao.fetchAll();

		for (RegisterStudent studentEmailList1 : studentEmailList) {
			if (fetchedEmail.equals(studentEmailList1.getEmailAddress())) {
				if (fetchedPassword.equals(studentEmailList1.getPassword())) {
					flag = true;
					return flag;
				} else {

				}
			}
		}
		return false;
	}
}
