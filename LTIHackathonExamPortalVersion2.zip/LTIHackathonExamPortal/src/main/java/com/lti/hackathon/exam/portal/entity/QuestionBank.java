package com.lti.hackathon.exam.portal.entity;

import java.util.Set;
import com.lti.hackathon.exam.portal.entity.OptionList;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "QuestionBank")
public class QuestionBank {
//	@Override
//	public String toString() {
//		return "QuestionBank [questionId=" + questionId + ", question=" + question + ", domain=" + domain + ", stage="
//				+ stage + ", options=" + options + "]";
//	}

	@Id
	@GeneratedValue
	private int questionId;
	private String question;
	private String domain;
	private int stage;

	@OneToMany( mappedBy = "questionBank", fetch=FetchType.EAGER,cascade= CascadeType.ALL)
	private Set<OptionList> options;

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public int getstage() {
		return stage;
	}

	public void setstage(int stage) {
		this.stage = stage;
	}

	public Set<OptionList> getOptions() {
		return options;
	}

	public void setOptions(Set<OptionList> options) {
		this.options = options;
	}

}
